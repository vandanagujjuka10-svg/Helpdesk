
package com.helpdesk.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.helpdesk.entity.Ticket;
import com.helpdesk.repository.TicketRepository;

@Service
public class TicketService {

    @Autowired
    private TicketRepository repo;

    public List<Ticket> getAllTickets() {
        return repo.findAll();
    }

    public Ticket saveTicket(Ticket ticket) {
        return repo.save(ticket);
    }

    public void deleteTicket(Long id) {
        repo.deleteById(id);
    }
}
