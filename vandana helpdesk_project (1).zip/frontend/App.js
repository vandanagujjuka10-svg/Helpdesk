
import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [tickets, setTickets] = useState([]);
  const [title, setTitle] = useState("");

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = () => {
    axios.get("http://localhost:8080/api/tickets")
      .then(res => setTickets(res.data));
  };

  const addTicket = () => {
    axios.post("http://localhost:8080/api/tickets", {
      title,
      description: "Test issue",
      status: "OPEN"
    }).then(fetchTickets);
  };

  return (
    <div>
      <h2>Help Desk</h2>
      <input value={title} onChange={e => setTitle(e.target.value)} />
      <button onClick={addTicket}>Add Ticket</button>
      <ul>
        {tickets.map(t => (
          <li key={t.id}>{t.title} - {t.status}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
